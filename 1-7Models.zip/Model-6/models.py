import matplotlib.pyplot as plt
from keras.src.layers import Reshape, SimpleRNN, LSTM
from tensorflow.keras import Sequential

from tensorflow.keras.layers import Dense,Flatten,Conv2D,MaxPool2D,BatchNormalization,Dropout

from tensorflow.keras.applications.vgg16 import VGG16

from keras.regularizers import l2


class DeepCNN():

    def simple_model(self, input_shape=(28,28,3), op="sgd", regularizers_sterength=0.01):
        cnn = Sequential()
        cnn.add(Conv2D(filters=32, kernel_size=3, activation='relu', input_shape=[28,28,3]))
        cnn.add(MaxPool2D(pool_size=2, strides=2))
        cnn.add(BatchNormalization())
        cnn.add(Dropout(0.2))
        cnn.add(Conv2D(filters=32, kernel_size=3, activation='relu'))
        cnn.add(MaxPool2D(pool_size=2, strides=2))
        cnn.add(Flatten())
        cnn.add(Dense(500, kernel_regularizer=l2(regularizers_sterength), activation="relu"))
        cnn.add(Dense(units=7, activation='sigmoid',kernel_regularizer=l2(regularizers_sterength)))
        cnn.add(Dropout(0.2))

        cnn.compile(optimizer = 'sgd', loss = 'categorical_crossentropy', metrics = ['accuracy'])

        return cnn

    def cnn_regularizer_model(self, input_shape=(28, 28, 3), op="sgd", regularizers_sterength=0.001):
        cnn = Sequential()
        cnn.add(Conv2D(filters=32, kernel_size=3, activation='relu', input_shape=[32, 32, 3]))
        cnn.add(MaxPool2D(pool_size=2, strides=2))
        cnn.add(BatchNormalization())
        cnn.add(Dropout(0.2))
        cnn.add(Conv2D(filters=32, kernel_size=3, activation='relu'))
        cnn.add(MaxPool2D(pool_size=2, strides=2))
        cnn.add(Flatten())
        cnn.add(Dense(500, kernel_regularizer=l2(regularizers_sterength), activation="relu"))
        cnn.add(Dense(units=7, activation='sigmoid', kernel_regularizer=l2(regularizers_sterength)))
        cnn.add(Dropout(0.2))

        cnn.compile(optimizer='sgd', loss='categorical_crossentropy', metrics=['accuracy'])

        return cnn


    def cnn_transform_model(self,input_shape=(28,28,3),op="sgd"):
        cnn=Sequential()
        cnn.add(VGG16(weights="imagenet", include_top=False ,input_shape=(32,32,3)))
        cnn.add(Flatten())
        cnn.add(Dense(1024,activation='relu', input_shape=[32, 32,3]))
        cnn.add(Dense(128, activation='relu'))
        cnn.add(Dense(64, activation='relu'))
        cnn.add(Dense(7, activation='softmax'))

        cnn.compile(loss="categorical_crossentropy", optimizer=op, metrics=['accuracy'])

        return cnn

